def nrcif(n):
    """
    Compute the number of digits of the parameter number
    :param n(int): The integer number for which to compute the number of digits
    :return nr(int): The number of digits of the parameter number
    """
    nr = 0
    while (n):
        nr = nr + 1
        n = int(n / 10)
    return nr


def ex13(n):
    """
    Compute a number using the digits found on odd positions in the input number
    :param n(int): The integer input number for which to compute the number resulting from the digits on odd positions
    :return nr(int): The number formed with the digits found on odd positions in the input number
    """
    p = 1
    digit = nrcif(n)
    nr = 0
    while (n):
        if (digit % 2 == 1):
            nr = (n % 10) * p + nr
            p = p * 10
        digit = digit - 1
        n = int(n / 10)
    return nr

if __name__ == "__main__":
    n = int(input())
    print(ex13(n))