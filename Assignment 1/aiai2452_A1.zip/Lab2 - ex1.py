def ex1(n):
    """
    Compute the control digit of an integer
    Parameters: n (int) - The input integer for which to compute the control digit
    Returns: int - The control digit of the input integer
    Returns 9 if n is divisible by 9, otherwise returns n % 9
    """
    if n % 9 == 0:
        return 9
    return n % 9

if __name__ == "__main__":
    n = int(input())
    print(ex1(n))