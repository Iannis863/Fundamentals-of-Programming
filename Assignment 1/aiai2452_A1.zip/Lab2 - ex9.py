def ex9():
    """
    Compute all the numbers with maximum 2 digits where the last digit of the number is equal to the last digit of the number at the power of two
    Parameters: none
    Prints all the numbers with maximum 2 digits where the last digit of the number is equal to the last digit of the number at the power of two
    """
    for i in range(100):
        if (i * i % 10 == i % 10):
            print(i, " ")

if __name__ == "__main__":
    ex9()