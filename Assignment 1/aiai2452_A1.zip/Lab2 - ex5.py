def ex5(k):
    """
    Return the element on position k in the array 1,2,2,3,3,3,4,4,4,4,...
    Parameters: n(int) - The input integer for which to compute the element.
    Returns: int - the element in the array 1,2,2,3,3,3,... on the input intiger position
    """
    x = 1
    while (k >= x):
        k = k - x
        x = x + 1
    if (k == 0):
        return x - 1
    return x

if __name__ == "__main__":
    k = int(input())
    print(ex5(k))