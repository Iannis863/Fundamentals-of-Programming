def nrcif(n):
    """
    Compute the number of digits of the parameter number
    :param n(int): The integer number for which to compute the number of digits
    :return nr(int): The number of digits of the parameter number
    """
    nr = 0
    while (n):
        nr = nr + 1
        n = int(n / 10)
    return nr

def sumdig(n):
    """
        Compute the sum of digits of the parameter number
        :param n(int): The integer number for which to compute the sum of digits
        :return s(int): The sum of digits of the parameter number
        """
    s = 0
    while (n):
        s = s + n % 10
        n = int(n / 10)
    return s


def ex17(n):
    """
    Compute if a number is a special number or not
    A special number is a number who is the sum of another number and the sum of it's digits
    :param n(int): The integer number for which to compute if it is a special number or not
    :return: True if the number is a special number and False otherwise
    """
    for i in range(n, n - 9 * nrcif(n), -1):
        if (n == i + sumdig(i)):
            return True
    return False

if __name__ == "__main__":
    n = int(input())
    print(ex17(n))